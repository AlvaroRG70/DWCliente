class Integrante{
    constructor(dni, nombre, apellido){
        this.dni = dni
        this.nombre = nombre
        this.apellido = apellido
    }
}